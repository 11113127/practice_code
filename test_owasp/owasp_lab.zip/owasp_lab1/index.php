<p>TOP10</p>
<p><a href="top10/">Top10 Sample1</a></p>
<p><a href="top10/index2.php?url=safe.php">Top10 Sample2</a></p>
<p><a href="top10/index2.php?url=unsafe.php">Top10 Sample3</a></p>
<p><a href="top10/index2.php?url=http://www.google.com">Top10 Sample4</a></p>
<p>TOP8</p>
<p><a href="top8">Top8 Sample1</a></p>
<p><a href="top8/cost.php?cost=2000">Top8 Sample Test</a></p>
<p>TOP7</p>
<p><a href="top7/">Top7 Sample1</a></p>
<p><a href="top7/login.php?login=aaa">Top7 Sample Test</a></p>
<p>==============Mod===============</p>
<p>TOP10</p>
<p><a href="top10_mod/">Top10 Sample1</a></p>
<p><a href="top10_mod/index2.php?url=safe.php">Top10 Sample2</a></p>
<p><a href="top10_mod/index2.php?url=unsafe.php">Top10 Sample3</a></p>
<p><a href="top10_mod/index2.php?url=http://www.google.com">Top10 Sample4</a></p>
<p>TOP8</p>
<p><a href="top8_mod/">Top8 Sample1</a></p>
<p><a href="top8_mod/cost.php?cost=2000">Top8 Sample Test</a></p>
<p>TOP7</p>
<p><a href="top7_mod/">Top7 Sample1</a></p>
<p><a href="top7_mod/login.php?login=aaa">Top7 Sample Test</a></p>
