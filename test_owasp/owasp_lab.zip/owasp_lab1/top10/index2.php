<?php
if( !empty($_GET['url']) ){
    header( 'Location: '.$_GET['url'] );
}

?>
