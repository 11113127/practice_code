<?php
session_start();
// 如果有登入前頁面的話，接收參數
if($_GET['url'] != ''){
    $url = $_GET['url'];
}
?>
<form name="form1" action="login.php?url=<?php print($url);?>" method="post">
<p> 帳號: <input type="text" name="login_id"> </p>
<p> 密碼: <input type="password" name="login_pwd"> </p>
<p> <input type="submit" name="submit" value="登入"> </p>
</form>
